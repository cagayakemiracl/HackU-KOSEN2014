
//
//  ProgressProgram.swift
//  Poli
//
//  Created by Ashigirl96 on 2015/03/14.
//  Copyright (c) 2015年 西村 礼恩. All rights reserved.
//

/*
SelectMenu2_1.swift
    1.Navigationにすること
    2.Label付けること
    3.1ImageView付けること.
    3.2.ImageViewにIDをつけて、Buttonを押すことで何番目を選んだか分かるようにする
    4.NavigationにFav☆を付けること

DrawerMenu2_1_1.swift
    1.fav Listを見やすく出てくるようにする

SelectPic2_2.swift
    1.選ばれたImageViewのIDから文字列を選び、Labelにする
    2.ImageViewをPushボタンにすることで遷移先(ここ)に<backを付けるようにする
    3.1.ImageViewにIDを付ける
    3.2.IDの奇数偶数で、左右を決める
    3.3.Scroll Viewを使うことでスクロール可能にする←質問余地あり

Problem.
　　画像とフレームを大きくしすぎてる←AppDelegateの参照してるクラスが違った
　　fav（Drawer)Menuのボタンでない←同上
　　画像上に字が書かれてる
　　画像/フレームのサイズが240x240のまま
　　スクロールできない
　　スクロールしても止まる
　　フレームの左右のサイズがオカシイ

*/